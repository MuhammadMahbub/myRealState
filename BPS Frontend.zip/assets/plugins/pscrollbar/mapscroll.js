// ______________ PerfectScrollbar
const ps10 = new PerfectScrollbar('.vscroll',{
	useBothWheelAxes:true,
	suppressScrollX:true,
});